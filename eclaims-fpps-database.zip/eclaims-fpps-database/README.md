# eClaims FPPS Database

Fee Payment Processing System (FPPS) Community Care Claim data and Veteran claim data is moved into the FPPS Owner database schema. FPPS also coordinates claim adjudication and remittance data. After receiving payment details from the Central Fee system and adjudication decisions from the Fee Basis Claims System (FBCS), FPPS communicates this data the EDI Gateway system for it to create outbound claim remittance files.

Add documentaion for configuration management and deployment of your code, including:
- build and deploy instructions
- information on automated tests, and where to find results 
- instructions for how to set up local development


## Product
- Product Name: eClaims
- Product Line Portfolio: FPPS

### Team Contacts

- Maintained by: @department-of-veterans-affairs/eclaims-cm
- Project Manager: @cvanzo
- Technical Team Lead: @cvanzo
- Configuration Manager: @Cheryl-Lach/@lbenhartVA


## Code Description


### Deployment


#### Branching strategy

Certain branches are special, and would ordinarily be deployed to various test environments:

- master: our default branch, for production-ready code. Master is always deployable. In our case, however, deployment does not happen automatically.
- pre-prod: code destined for the pre-production test server. This code might be deployed by hand or automatically, depending on the project and availability of a CI/CD solution.
- test: code that would probably autotmatically be pushed to a test or staging server. Again, in our case we don't do this -- but test deployment tasks like this are ideally automated with a CI/CD solution like Jenkins.

New code should be produced on a feature branch [following GitHub flow](https://guides.github.com/introduction/flow/). Most often, you'll want to branch from **master**, since that's the latest in production. File a pull request to merge into **test**, which can be deployed to our testing environment.



### Testing




### Installing




### License

See the [LICENSE](LICENSE.md) file for license rights and limitations.
