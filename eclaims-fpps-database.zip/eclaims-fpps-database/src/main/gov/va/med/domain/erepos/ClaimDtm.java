package gov.va.med.domain.erepos;


// Generated Jun 30, 2009 4:03:22 PM by Hibernate Tools 3.2.4.GA
import java.math.BigDecimal;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@SuppressWarnings("serial")
@Entity(name = "eClaimDtm")
@Table(name = "CLAIM_DTM", schema = "E_REPOS")
public class ClaimDtm implements java.io.Serializable {
    private String claimDtmKey;
    private TxnSet txnSet;
    private ClaimPymtInfo claimPymtInfo;
    private SvcPymtInfo svcPymtInfo;
    private BigDecimal seqNbr;
    private String dtm01Qual;
    private String dtm02dtFld;
    private String createdBy;
    private Date dateCreated;
    private String modifiedBy;
    private Date dateModified;

    public ClaimDtm() {
    }

    public ClaimDtm(String claimDtmKey, BigDecimal seqNbr,
        String dtp01dttmQual) {
        this.claimDtmKey = claimDtmKey;
        this.seqNbr = seqNbr;
        this.dtm01Qual = dtp01dttmQual;
    }

    public ClaimDtm(String claimDtmKey, TxnSet txnSet,
        ClaimPymtInfo claimPymtInfo, SvcPymtInfo svcPymtInfo, BigDecimal seqNbr,
        String dtp01dttmQual, String dtp02dttmFmtQual, String dtp03dtFld,
        String createdBy, Date dateCreated, String modifiedBy, Date dateModified) {
        this.claimDtmKey = claimDtmKey;
        this.txnSet = txnSet;
        this.claimPymtInfo = claimPymtInfo;
        this.svcPymtInfo = svcPymtInfo;
        this.seqNbr = seqNbr;
        this.dtm01Qual = dtp01dttmQual;
        this.dtm02dtFld = dtp03dtFld;
        this.createdBy = createdBy;
        this.dateCreated = dateCreated;
        this.modifiedBy = modifiedBy;
        this.dateModified = dateModified;
    }

    @Id
    @Column(name = "CLAIM_DTM_KEY", unique = true, nullable = false, length = 36)
    public String getClaimDtmKey() {
        return this.claimDtmKey;
    }

    public void setClaimDtmKey(String claimDtmKey) {
        this.claimDtmKey = claimDtmKey;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({@JoinColumn(name = "FILE_NUMBER",referencedColumnName = "FILE_NUMBER")
        , @JoinColumn(name = "ST02TXN_CTL_NBR",referencedColumnName = "ST02TXN_CTL_NBR")
    })
    public TxnSet getTxnSet() {
        return this.txnSet;
    }

    public void setTxnSet(TxnSet txnSet) {
        this.txnSet = txnSet;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CLAIM_PYMT_INFO_KEY")
    public ClaimPymtInfo getClaimPymtInfo() {
        return this.claimPymtInfo;
    }

    public void setClaimPymtInfo(ClaimPymtInfo claimPymtInfo) {
        this.claimPymtInfo = claimPymtInfo;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SVC_PYMT_INFO_KEY")
    public SvcPymtInfo getSvcPymtInfo() {
        return this.svcPymtInfo;
    }

    public void setSvcPymtInfo(SvcPymtInfo svcPymtInfo) {
        this.svcPymtInfo = svcPymtInfo;
    }

    @Column(name = "SEQ_NBR", nullable = false, precision = 22, scale = 0)
    public BigDecimal getSeqNbr() {
        return this.seqNbr;
    }

    public void setSeqNbr(BigDecimal seqNbr) {
        this.seqNbr = seqNbr;
    }

    @Column(name = "DTM01_QUAL", nullable = false, length = 3)
    public String getDtm01Qual() {
        return this.dtm01Qual;
    }

    public void setDtm01Qual(String dtm01Qual) {
        this.dtm01Qual = dtm01Qual;
    }

    @Column(name = "DTM02DT_FLD", length = 35)
    public String getDtm02dtFld() {
        return this.dtm02dtFld;
    }

    public void setDtm02dtFld(String dtm02dtFld) {
        this.dtm02dtFld = dtm02dtFld;
    }

    @Column(name = "CREATED_BY", length = 20)
    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_CREATED", length = 7)
    public Date getDateCreated() {
        return this.dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    @Column(name = "MODIFIED_BY", length = 20)
    public String getModifiedBy() {
        return this.modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_MODIFIED", length = 7)
    public Date getDateModified() {
        return this.dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }
}
