---
name: Test
about: Describes User Story Testing
title: 'Test - '
labels: test
assignees: ''

---

## Test

### Description


Tests User Story: #



### Automated tests

List any automated tests that verify this feature.



### Test Steps (if no testing tool)

Feel free to include screenshots or any other context to help a tester understand how the feature works when it's working properly.

Replace this sample test with your own test plan:

- [ ] Step 1
- [ ] Step 2...



### Link to Test Cases, Scripts and Results (in your Test Management and Execution Tool):

