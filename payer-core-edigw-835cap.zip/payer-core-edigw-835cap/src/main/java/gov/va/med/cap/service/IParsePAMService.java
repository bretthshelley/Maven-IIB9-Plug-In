package gov.va.med.cap.service;

import gov.va.med.cap.model.request.ParsePAMRequest;

public interface IParsePAMService {
	public boolean processPAMBatch(ParsePAMRequest parsePamRequest);
	public void deleteOldRecords(int numberOfDays);
}
