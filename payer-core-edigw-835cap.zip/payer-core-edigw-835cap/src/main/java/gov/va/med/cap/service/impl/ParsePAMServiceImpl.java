/****************************************************
Description: Created the class to parse 277CA file
to produce the required data and save in database
for further processing. Logic mainly follows back track 
method.
Date Modified: 06/28/2018 	Date Created: 06/14/2018
*****************************************************/

package gov.va.med.cap.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import gov.va.med.cap.dao.erepos.IEreposPamRepository;
import gov.va.med.cap.model.request.ParsePAMRequest;
import gov.va.med.cap.service.IParsePAMService;
import gov.va.med.domain.ereposModel.PamHolding;

@Service
public class ParsePAMServiceImpl implements IParsePAMService {
	private static final Logger logger = LogManager.getLogger(ParsePAMServiceImpl.class);
	SimpleDateFormat format = new SimpleDateFormat("yyMMdd");

	@Autowired
	IEreposPamRepository ereposPamRepository;

	@Value("${pm.file.delimiter}")
	private String pamFileDelimiter;
	@Value("${emailRecipients}")
	private String emailRecipients;
	@Value("${emailSender}")
	private String emailSender;
	private static final String BREAK = "<br/>";
	
	@Override
	public boolean processPAMBatch(ParsePAMRequest parsePamRequest) {
	
		String[] lineStrings = parsePamRequest.getPamString().split("\n");
		List<String> errorLineStrs = new ArrayList<String>();
		String pamFileName = parsePamRequest.getOriginalFileName();
		logger.info("PAM file Name : " + pamFileName);
		logger.info("PAM file String " + parsePamRequest.getPamString());
		logger.info("PAM file String Split" + lineStrings);

		List<PamHolding> pamHoldingList = new ArrayList<PamHolding>();
		int lineNumber = 1;
		for (String lineString : lineStrings) {
			logger.info("lineString " + lineString);
			logger.info ("Length "+lineString.length());
			if (lineString != null && lineString.trim().length() == 34) {
				
				String[] pamValueStrings = lineString.split(pamFileDelimiter);
				logger.info("pamValueStrings " + pamValueStrings.toString());
				int i = 0;
				String cmScheduleNumber = "";
				Date disbursementDate = null;
				String disbursementDateStr = "";
				String fmsScheduleNumber = "";
				String fmsPaymentSequenceNumber = "";
				String fmsDocumentId = "";
				String fmsDocumentType = "";
				java.util.Date currentDate = Calendar.getInstance().getTime();
				PamHolding pamHolding = new PamHolding();
				
				for (String pamValue : pamValueStrings) {
					logger.info("pamValue " + pamValue);
					
					if (i == 0) {
						cmScheduleNumber = pamValue.substring(0, 2);
						disbursementDateStr = pamValue.substring(2, 8);
						fmsScheduleNumber = pamValue.substring(8, 11);

						try {
							disbursementDate = format.parse(disbursementDateStr);
						} catch (ParseException e) {
							logger.error("Parse Exception while processPAMBatch", e);
							e.printStackTrace();
						}
						pamHolding.setCmScheduleNum(cmScheduleNumber);
						pamHolding.setDisbursementDate(disbursementDate);
						pamHolding.setFmsScheduleNum(fmsScheduleNumber);

					}
					if (i == 1) {
						fmsPaymentSequenceNumber = pamValue;
						pamHolding.setFmsPaymentSeqNum(fmsPaymentSequenceNumber);
					}
					if (i == 2) {
						fmsDocumentId = pamValue.substring(2, 13);
						fmsDocumentType = pamValue.substring(0, 2);
						pamHolding.setFmsDocId((fmsDocumentId != null ? fmsDocumentId.trim() : null));
						pamHolding.setFmsDocType(fmsDocumentType);
					}
					
					i++;
				}
				
				logger.info("fmsTrace:" + lineString.substring(0, 20));
				pamHolding.setFmsTrace(lineString.substring(0, 20));
				pamHolding.setDateCreated(currentDate);
				pamHoldingList.add(pamHolding);

				logger.info("all pam values " + cmScheduleNumber + " : " + disbursementDate + " : " + fmsScheduleNumber
						+ " : " + fmsPaymentSequenceNumber + " : " + fmsDocumentId + " : " + fmsDocumentType);

			
			logger.info("List size:" + pamHoldingList.size());

			for (PamHolding pam : pamHoldingList) {
				logger.info("pam values" + pam);
			}
			ereposPamRepository.saveAll(pamHoldingList);
			logger.info("Successfully inserted " + pamHoldingList.size() + " rows in database");
		}
		else{
			logger.error("Error in incoming PAM file for row "+ lineNumber);
			errorLineStrs.add(String.valueOf(lineNumber)); 
		}
			
			lineNumber++;
		}
       try {
    	    logger.info("Invoking sendEmail method");
        	if (errorLineStrs.size()>0 ) {        		
        		sendEmail(pamFileName,errorLineStrs);
        	}
        }catch(Exception e){
        	logger.error("Got error when sending email for errored out lines", e);
        }
		return true;
	}

	/**
	 * Delete the records that are given number days old
	 * 
	 * @param numberOfDays
	 *            numbers of days before for which records needs to be deleted
	 */
	public void deleteOldRecords(int numberOfDays) {

		/*
		 * Calculate the expiry date
		 */
		logger.info("deleteOldRecords : numberOfDays: " + numberOfDays);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_YEAR, (-numberOfDays));
		Date expiryDate = cal.getTime();
		logger.info("expiryDate: " + expiryDate);
		try {
			ereposPamRepository.deleteByDateCreatedBeforeAndMatched835Flg(expiryDate, 'Y');
		} catch (Exception ex) {
			logger.error("SQL Exception while deleting Expired records", ex);
			ex.printStackTrace();
		}
	}
	
    private void sendEmail(String pamFileName,List<String> errorLineStrs) {
    	logger.info("Inside sendEmail method");

		// Set the host SMTP address
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.va.gov");
		props.put("mail.host", "smtp.va.gov");
		
		try {
			// create some properties and get the default Session
			Session session = Session.getInstance(props);
			session.setDebug(false);
			
			// create a message
			Message msg = new MimeMessage(session);
	
			// Set From Address		
			InternetAddress addressFrom = new InternetAddress(emailSender);
			msg.setFrom(addressFrom);	
			
			// VA Address
			String[] recipients = emailRecipients.split(",");
			
			// recipient
			 InternetAddress[] addressTo = new InternetAddress[recipients.length];
			 int recipientCount = 0;
			 for (String recipient : recipients) {
					if (recipient != null && !recipient.equals("")) {
						InternetAddress addressTemp = new InternetAddress(recipient);
						addressTemp.validate();
						addressTo[recipientCount] = addressTemp;
						recipientCount++;
					}
			 }
			 
			// Set To Address		
			msg.setRecipients(Message.RecipientType.TO, addressTo);
	
			// Setting the Subject and Content Type
			msg.setSubject("835 CHAMPVA ERROR");
			msg.setContent(buildEmailBody(pamFileName,errorLineStrs), "text/html");
			Transport.send(msg);
		} catch (Exception e) {
			logger.error("Error while sending email",e );			
		}
	}
	
    private String buildEmailBody(String pamFileName, List<String> errorLineStrs)
	{ 
		logger.info("Inside buildEmailBody method");
		java.util.Date currentDate = Calendar.getInstance().getTime();
		// create the email body
		StringBuffer emailBodyBuffer = new StringBuffer();
		StringBuffer emailBody = new StringBuffer();
	     emailBody.append(" FileName : ");
	     emailBody.append(pamFileName);
	     emailBody.append(", Errored out line numbers :");
	     for(String lineNumber : errorLineStrs) {
	    	 emailBody.append(lineNumber);
	    	 emailBody.append(",");
	     }
	     emailBody.append(" Processed Date : ");
	     emailBody.append(currentDate);
				
		emailBodyBuffer.append("Hello,");
		emailBodyBuffer.append(BREAK);
		emailBodyBuffer.append(BREAK);
		emailBodyBuffer.append("The following PAM files encountered an error while generating an 835 file.");
		emailBodyBuffer.append(emailBody);
		emailBodyBuffer.append(BREAK);
		emailBodyBuffer.append(BREAK);
		emailBodyBuffer.append("CHAMPVA Administrator");
		emailBodyBuffer.append(BREAK);
		emailBodyBuffer.append(BREAK);
		
		logger.info("build email body "+ emailBodyBuffer.toString());
		
		return emailBodyBuffer.toString();
	}
}