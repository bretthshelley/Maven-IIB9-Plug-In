package gov.va.med.file.watcher;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PAMFileArchiver {

	private static final Logger logger = LogManager.getLogger(PAMFileArchiver.class);
	private static final long NUMBER_OF_MILLISECONDS_TO_WAIT_PER_ARCHIVE_ATTEMPT = 500L;
	private static final long NUMBER_OF_MILLISECONDS_IN_SECOND = 1000L;

	private DateFormat dateFormat = new SimpleDateFormat("MMddyyyy-HHmmssSSS");

	public Path archiveFile(Path fileToBeArchived, String ingestFileArchiveDirectory) throws Exception {

		Path archiveFilePath = null;

		String originalfileName = fileToBeArchived.getFileName().toString();

		if (StringUtils.isNotBlank(originalfileName)) {

			archiveFilePath = Paths.get(FilenameUtils.normalize(ingestFileArchiveDirectory), FilenameUtils.normalize(originalfileName + dateFormat.format(new Date())));
			
			logger.info(String.format("Archiving original file %s into archive file %s", fileToBeArchived,
					archiveFilePath));

			int archivalAttemptCounter = 1;
			for (; archivalAttemptCounter <= 10; archivalAttemptCounter++) {

				try {
					Files.copy(fileToBeArchived, archiveFilePath);
					break;
				} catch (IOException ioe) {
					logger.warn(String.format("IOException occured on copying %s to %s, attempting to wait for %s ",
							fileToBeArchived, archiveFilePath,
							(archivalAttemptCounter * NUMBER_OF_MILLISECONDS_TO_WAIT_PER_ARCHIVE_ATTEMPT)
									/ NUMBER_OF_MILLISECONDS_IN_SECOND));
					if (archivalAttemptCounter == 10) {
						throw ioe;
					}
					try {
						Thread.sleep(archivalAttemptCounter * NUMBER_OF_MILLISECONDS_TO_WAIT_PER_ARCHIVE_ATTEMPT);
					} catch (InterruptedException e) {
						logger.warn(
								String.format("Error occured while attempting to sleep archiving thread for %s seconds",
										(archivalAttemptCounter * NUMBER_OF_MILLISECONDS_TO_WAIT_PER_ARCHIVE_ATTEMPT)
												/ NUMBER_OF_MILLISECONDS_IN_SECOND),
								e);
					}
				} catch (Exception e) {
					logger.error("Non IO Error occured while attemping to copy file.");
				}
			}

			if (archiveFilePath.toFile().exists() && archiveFilePath.toFile().isFile()
					&& (archiveFilePath.toFile().length() > 0
							|| (archiveFilePath.toFile().length() == 0 && fileToBeArchived.toFile().length() == 0))) {

				Files.setLastModifiedTime(archiveFilePath, FileTime.fromMillis(System.currentTimeMillis()));

				logger.info(String.format("File at path %s has been archived, deleting file now...",
						fileToBeArchived.toAbsolutePath()));
				try {
					Files.deleteIfExists(fileToBeArchived);
				} catch (IOException e) {
					logger.error(String.format("Error occured while attempting to delete file %s",
							fileToBeArchived.toAbsolutePath()), e);
				}
			}
		}

		return archiveFilePath;
	}

}
