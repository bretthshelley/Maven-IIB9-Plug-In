package gov.va.med.cap.scheduler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.va.med.cap.service.IParsePAMService;

@Component
public class ScheduledTasks {

	private static final Logger logger = LogManager.getLogger(ScheduledTasks.class);
	
	@Autowired 
	IParsePAMService parseService;
	@Value("${numberOfDays}") int numberOfDays;
	
	@Scheduled(cron = "${cron.expression}")
	public void scheduleTaskUsingCronExpression() {
		logger.info("Starting Cron job to delete old records");
		logger.info("numberOfDays:"+numberOfDays);
		parseService.deleteOldRecords(numberOfDays);
	    logger.info("schedule tasks using cron jobs ran successfully");
	}
}
