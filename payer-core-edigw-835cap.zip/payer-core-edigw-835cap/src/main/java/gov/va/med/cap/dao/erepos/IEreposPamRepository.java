package gov.va.med.cap.dao.erepos;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import gov.va.med.domain.ereposModel.PamHolding;

@Repository
public interface IEreposPamRepository extends JpaRepository<PamHolding, Long> {
	@Transactional
	@Modifying
	void deleteByDateCreatedBeforeAndMatched835Flg(Date expiryDate, char matched835Flg);
}
