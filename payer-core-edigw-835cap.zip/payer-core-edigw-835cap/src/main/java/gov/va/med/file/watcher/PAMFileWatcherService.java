package gov.va.med.file.watcher;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PAMFileWatcherService {

	private static final Logger logger = LogManager.getLogger(PAMFileWatcherService.class);

	@Autowired
	PAMFileWatcher fileWatcher;

	@PostConstruct
	public void postInit() {

		Thread fileWatchingThread = new Thread(fileWatcher, "fileWatcherThread");

		fileWatchingThread.start();

	}

	@PreDestroy
	public void close() {
		logger.info("Closing the PAMFileWatcherService");
		fileWatcher.stopWatcher();
	}

}
