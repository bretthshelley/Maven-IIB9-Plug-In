package gov.va.med.file.watcher;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import gov.va.med.cap.model.request.ParsePAMRequest;
import gov.va.med.cap.service.IParsePAMService;

public class PAMFileProcessor implements Runnable {

	private static final Logger logger = LogManager.getLogger(PAMFileProcessor.class);

	private static final Object LOCK = new Object();

	private Path fileToBeProcessed;
	private String pamFileArchiveDirectory;
	private IParsePAMService parseService;

	public PAMFileProcessor(Path fileToBeProcessed, String pamFileArchiveDirectory, IParsePAMService parseService) {
		this.fileToBeProcessed = fileToBeProcessed;
		this.pamFileArchiveDirectory = pamFileArchiveDirectory;
		this.parseService = parseService;
	}

	@Override
	public void run() {

		Path pathToFileThatWillBeParsed = null;

		// archive the file
		logger.info(
				"Routing file to archival: " + fileToBeProcessed + " -> Archive Directory: " + pamFileArchiveDirectory);
		try {
			pathToFileThatWillBeParsed = getNewFilePAMArchiver().archiveFile(fileToBeProcessed,
					FilenameUtils.normalize(pamFileArchiveDirectory));
		} catch (Exception e) {
			logger.warn(String.format("Error during archiving file %s.", fileToBeProcessed), e);
			pathToFileThatWillBeParsed = fileToBeProcessed;
		}

		if (pathToFileThatWillBeParsed.toFile() != null && pathToFileThatWillBeParsed.toFile().exists()
				&& pathToFileThatWillBeParsed.toFile().length() > 0) {

			// send content to processor
			logger.info("Sending content in file to PAM parser: " + pathToFileThatWillBeParsed + " -> using Parser: "
					+ parseService.toString());

			boolean parseSuccess = false;

			synchronized (LOCK) {

				parseSuccess = readFileIntoParseService(pathToFileThatWillBeParsed, parseService,
						fileToBeProcessed.getFileName().toString());
			}

			if (parseSuccess) {
				logger.info(String.format("File located at %s was parsed correctly", pathToFileThatWillBeParsed));
			} else {
				logger.info(String.format("File located at %s was not parsed correctly", pathToFileThatWillBeParsed));
			}

		} else {
			logger.info(String.format(
					"File located at %s did not meet conditions (not null, exists, and has content) to be parsed.",
					pathToFileThatWillBeParsed));
		}

	}

	private boolean readFileIntoParseService(Path archiveFileToBeRead, IParsePAMService parseService,
			String originalFileName) {

		boolean success = false;

		try {
			String fileContents = new String(Files.readAllBytes(archiveFileToBeRead));
			ParsePAMRequest parseRequest = new ParsePAMRequest(fileContents, originalFileName);
			parseService.processPAMBatch(parseRequest);
			success = true;
		} catch (IOException e) {
			logger.error(String.format("Error where attempting to read file %s into byte array",
					archiveFileToBeRead.toString()), e);
		}

		return success;

	}

	private PAMFileArchiver getNewFilePAMArchiver() {
		return new PAMFileArchiver();
	}

}
