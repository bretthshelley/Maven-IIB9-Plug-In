package gov.va.med.cap.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Component
public class ParsePAMRequest {

	private String pamString;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String originalFileName;

	

	public ParsePAMRequest(String pamString, String originalFileName) {
		super();
		this.pamString = pamString;
		this.originalFileName = originalFileName;
	}

	public String getPamString() {
		return pamString;
	}

	public void setPamString(String pamString) {
		this.pamString = pamString;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	
}
