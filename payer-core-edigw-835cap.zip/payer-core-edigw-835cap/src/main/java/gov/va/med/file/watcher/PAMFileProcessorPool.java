package gov.va.med.file.watcher;

import java.io.File;
import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import gov.va.med.cap.service.IParsePAMService;

@Component
public class PAMFileProcessorPool {

	private static final Logger logger = LogManager.getLogger(PAMFileProcessorPool.class);
	private static final int DEFAULT_NUMBER_OF_THREADS = 10;

	@Autowired
	IParsePAMService parseService;

	@Value("${gov.va.med.pam.file.watcher.processor.threads}")
	private String numberOfThreads;

	@Value("${gov.va.med.pam.file.watcher.directory.archive}")
	String pamFileArchiveDirectory;

	private ExecutorService threadPool;

	@PostConstruct
	public void postInit() {
		checkInitialization();
	}

	private boolean checkInitialization() {

		// initialize archive directory
		File directoryToBeCreatedIfNotThere = new File(FilenameUtils.normalize(pamFileArchiveDirectory));

		if (!(directoryToBeCreatedIfNotThere.exists() && directoryToBeCreatedIfNotThere.isDirectory())) {

			logger.info("Directory to be archived to does not exist, creating...");

			boolean success = directoryToBeCreatedIfNotThere.mkdirs();

			if (!success) {
				logger.error("Directory to be archived to could not be created");
			}
		}

		// initialize thread pool if not available
		if (threadPool == null || threadPool.isShutdown()) {

			int initNumberOfThreads = DEFAULT_NUMBER_OF_THREADS;

			if (StringUtils.isNotBlank(numberOfThreads) && StringUtils.isNumeric(numberOfThreads.trim())) {
				logger.info("Initializing pamFileProcessorPool with number of threads from properties: "
						+ numberOfThreads);
				initNumberOfThreads = Integer.parseInt(numberOfThreads);
			} else {
				logger.info("Initializing pamFileProcessorPool with default number of threads from class: "
						+ numberOfThreads);
			}

			threadPool = Executors.newFixedThreadPool(initNumberOfThreads);
		}

		return directoryToBeCreatedIfNotThere.exists() && directoryToBeCreatedIfNotThere.isDirectory()
				&& threadPool != null;
	}

	public void startProcessingReceivedFile(Path receivedFile) {

		if (checkInitialization()) {

			logger.info("Inside pamFileProcessorPool.startProcessingReceivedFile, received file: "
					+ receivedFile.toString());

			PAMFileProcessor fileProcessor = new PAMFileProcessor(receivedFile, pamFileArchiveDirectory,
					parseService);
			threadPool.submit(fileProcessor);

		} else {
			logger.info("Cannot process file located at: " + receivedFile
					+ " due to either archive directory not being available or thread pool not available.");
		}
	}

	@PreDestroy
	public void close() {
		if (threadPool != null && !threadPool.isTerminated()) {
			threadPool.shutdown();
			try {
				if (!threadPool.awaitTermination(1000, TimeUnit.MILLISECONDS)) {
					threadPool.shutdownNow();
				}
			} catch (InterruptedException e) {
				if (threadPool != null) {
					threadPool.shutdownNow();
				}
			}
		}
	}
}
